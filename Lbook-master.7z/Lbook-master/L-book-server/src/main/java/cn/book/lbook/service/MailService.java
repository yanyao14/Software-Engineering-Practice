package cn.book.lbook.service;

public interface MailService {
    // 发送邮件
    String sendMail(String phoneNumber);
}
