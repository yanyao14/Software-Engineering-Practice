package cn.book.lbook.entity;

import lombok.Data;

import java.util.List;

@Data
public class Orders {

    private List<Order> orders;
}
