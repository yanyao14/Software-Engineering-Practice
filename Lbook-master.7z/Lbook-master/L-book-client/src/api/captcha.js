// captcha.js
const express = require('express');
const captchagen = require('captchagen');

const router = express.Router();

router.get('/captcha', (req, res) => {
  const captcha = captchagen();

  res.type('png');
  captcha.stream().pipe(res);
});

module.exports = router;
