<template>
  <div class="container-fluid py-5 home" lazy="loaded">
    <div class="row justify-content-center py-5">
      <div class="text-center col-md-12">
        <div class="title">Welcome！</div>
        <div class="subtitle mb-5">关于我们</div>
        <div class="text">
          欢迎来到我们的网上书店，我们致力于为读者提供一个丰富、多元的在线书店。无论您是在寻找经典文学、畅销小说，还是专业书籍，本网站都能满足您的需求。
        </div>
      </div>
      <div class="text-center col-md-12">
        <div class="title">Join Us</div>
        <div class="subtitle mb-5">加入我们</div>
        <div class="text">
          注册成为会员，享受专属优惠和会员特权。让我们一起探索书籍的世界吧！
        </div>
      </div>
      <div class="mt-4">
        <button class="btn btn-primary" @click="$router.push('/books')">
          开始探索
        </button>
      </div>
    </div>
    <div class="textBox">
      <transition name="slide">
        <p class="text" :key="text.id">
          <el-tag type="warning">{{ text.val.tag }}</el-tag>
          {{ text.val.title }}
        </p>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      imgUrl: "../../../public/images/home.png",
    };
  },
};
</script>

<style scoped>
.title {
  font-family: Calibri;
  font: 72px bold;
  color: #fff;
}

.subtitle {
  font-size: 16px;
  font-family: 等线;
  color: #fff;
}

.text {
  width: 60%;
  margin: 0 auto;
  font-size: 20px;
  color: #fff;
}

.home[lazy="loaded"] {
  height: 800px;
  background: url("../../../public/images/home.png");
  background-size: cover;
  background-position: center;
}
</style>

<script>
export default {
  name: "scroll",
  data() {
    return {
      textArr: [
        { tag: "精彩推荐", title: "书架上新！《追风筝的人》经典之作！" },
        { tag: "热门推荐", title: "大家都在看《哈利波特》" },
        { tag: "精彩推荐", title: "《想不出来了》全新译本~" },
        { tag: "公司公告", title: "网站开业第一天！首次下单免配送费" },
        { tag: "热门推荐", title: "不能错过！《好吗好的》大冰老师新作" },
      ],
      number: 0,
    };
  },
  computed: {
    text() {
      return {
        id: this.number,
        val: this.textArr[this.number],
      };
    },
  },
  mounted() {
    this.startMove();
  },
  methods: {
    startMove() {
      // eslint-disable-next-line
      let timer = setTimeout(() => {
        if (this.number === this.textArr.length) {
          this.number = 0;
        } else {
          this.number += 1;
        }
        this.startMove();
      }, 2500); // 滚动不需要停顿则将2000改成动画持续时间
    },
  },
};
</script>

<style scoped>
.textBox {
  width: 100%;
  height: 40px;
  margin: 0 auto;
  overflow: hidden;
  position: relative;
  text-align: center;
}
.text {
  width: 100%;
  position: absolute;
  bottom: 0;
}
.slide-enter-active,
.slide-leave-active {
  transition: all 0.5s linear;
}
.slide-enter {
  transform: translateY(20px) scale(1);
  opacity: 1;
}
.slide-leave-to {
  transform: translateY(-20px) scale(0.8);
  opacity: 0;
}
</style>