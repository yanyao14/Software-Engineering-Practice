<template>
    <div class="container">
        <h1>关于</h1>
        <hr>
        <div>
            <div>
                <span>
                    网上书店
                        （1）用户的注册，登录；
                        （2）用户的图书选购；
                        （3）店主对进书，售书，库存，账目，客户的管理；以及网站的日常维护（比如：网上书店简介；网上书店信息发布；客户留言及对客户留言的反馈）。
                        （4）一般客户可以浏览网上书店内容，欲购书的客户需注册取得唯一的用户名成为会员，会员登录后便可以购书一本或多本。
                </span>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "About"
    }
</script>

<style scoped>

</style>
